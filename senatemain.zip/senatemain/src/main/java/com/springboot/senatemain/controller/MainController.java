package com.springboot.senatemain.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {
	@RequestMapping("/")
	public String index() {
		System.out.println("Index Page");
		return "index";
	}
	
	@GetMapping("/adminpage")
	public String showadminPage(HttpServletRequest request) {
		HttpSession session=request.getSession();
		if(session.getAttribute("privilege")!=null && session.getAttribute("privilege").equals("admin")){
			System.out.println("Admin Page");
			System.out.println(session.getId());
			return "adminpage";
		}
		else {
			return "redirect:/";
		}
	}
	
	@GetMapping("/memberpage")
	public String showMemberPage(HttpServletRequest request) {
		HttpSession session=request.getSession();
		if(session.getAttribute("privilege")!=null && session.getAttribute("privilege").equals("member")){
			System.out.println("Member Page");
			System.out.println(session.getId());
			return "memberpage";
		}
		else {
			return "redirect:/";
		}
	}
	
	@GetMapping("/logout")
	public String logout(HttpServletRequest request) {
		System.out.println("Logout");
		HttpSession session=request.getSession();
		System.out.println(session.getId());
		session.invalidate();
		return "redirect:/";
	}
}
