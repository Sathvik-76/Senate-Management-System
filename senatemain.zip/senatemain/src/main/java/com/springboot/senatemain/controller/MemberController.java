package com.springboot.senatemain.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.senatemain.dao.MemberRepository;
import com.springboot.senatemain.entities.Member;

@Controller
public class MemberController {
	
	@Autowired MemberRepository memberRepository;
	
	//Admin Urls
	@GetMapping("/addmembers")
	public String showAddMemberForm(Model model) {
		System.out.println("Add members");
        model.addAttribute("member", new Member());
        return "add-member-form";
    }
	
	@PostMapping("/addmembers")
	public String addMember(@RequestParam(name = "status",required = false) String status,@ModelAttribute("member") Member member,Model model) {
		
		if(status!=null) {
			switch (status) {
			case "empty":
				model.addAttribute("message","Please fill out all the fields.");
				break;
			case "unique":
				model.addAttribute("message", "Email address is already in the list.");
                break;
			case "success":
				model.addAttribute("message", "Member added successfully.");
                break;
			}
			return "add-member-form";
		}
		else {
			if (member.getName().isEmpty() || member.getEmail().isEmpty() || member.getDesignation().isEmpty() || member.getPost().isEmpty()) {
	            return "redirect:/addmembers?status=empty";
	        }
	        if (memberRepository.findByEmail(member.getEmail())!=null) {
	            return "redirect:/addmembers?status=unique";
	        }
	        memberRepository.save(member);
	        return "redirect:/addmembers?status=success";
		}
    }
	
	@GetMapping("/memberlist")
	public String getMembers(Model model) {
		List<Member> members=memberRepository.findAll();
		model.addAttribute("members", members);
		return "memberlist";//the name of the view file
	}
	
	@GetMapping("/removemember")
	public String removeMember(@RequestParam("id") Integer id) {
		Optional<Member> member=memberRepository.findById(id);
		if(member.isPresent()) {
			memberRepository.delete(member.get());
		}
		return "redirect:/memberlist";
	}
	
	@GetMapping("/updatemember")
	public String showUpdateForm(@RequestParam("id") Integer id,Model model) {
		System.out.println("Show Update Form");
		Optional<Member> member=memberRepository.findById(id);
		if(member.isPresent()) {
			model.addAttribute("member", member.get());
			return "update-member-form";
		}
		else {
			return "redirect:/memberlist";
		}
	}
	
	@PostMapping("/updatemember")
	public String processUpdateForm(@ModelAttribute("member") Member member) {
		System.out.println("Process Update Form Begin");
		Member existingMember=memberRepository.findById(member.getId());
		if(existingMember!=null) {
			//System.out.println(existingMember.toString());
			existingMember.setName(member.getName());
			//System.out.println(existingMember.toString());
			existingMember.setEmail(member.getEmail());
			existingMember.setDesignation(member.getDesignation());
			existingMember.setPost(member.getPost());
			memberRepository.save(existingMember);
			System.out.println("Process Update Form End");
			return "redirect:/memberlist";
		}
		else {
			return "redirect:/memberlist";
		}
	}
	
	//Member Urls
	@GetMapping("/memberlistm")
	public String showMemberList(Model model) {
		List<Member> members=memberRepository.findAll();
		model.addAttribute("members", members);
		return "memberlistm";//the name of the view file
	}
}
