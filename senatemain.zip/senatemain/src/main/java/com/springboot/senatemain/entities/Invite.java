package com.springboot.senatemain.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="invite")
public class Invite {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int id;
	
	//private int meeting_id;
	
	@Column(name = "member_id")
	private int member_id;
	
	@Column(name="status")
	private int status;

	public Invite() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Invite(int id, int member_id, int status) {
		super();
		this.id = id;
		this.member_id = member_id;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMember_id() {
		return member_id;
	}

	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Invite [id=" + id + ", member_id=" + member_id + ", status=" + status + "]";
	}
	
}
