package com.springboot.senatemain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SenatemainApplication {

	public static void main(String[] args) {
		SpringApplication.run(SenatemainApplication.class, args);
	}

}
