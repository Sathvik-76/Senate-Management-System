package com.springboot.senatemain.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springboot.senatemain.entities.Member;
import com.springboot.senatemain.services.EmailService;
import com.springboot.senatemain.services.MemberService;

import jakarta.mail.MessagingException;

@Controller
public class EmailController {

	@Autowired
	private EmailService emailService;
	
	@Autowired
	private MemberService memberService;
	
	@GetMapping("/invitemember")
	public String inviteMember(@RequestParam Integer id) throws MessagingException{
		//get the member by id
		Member member=memberService.getMemberById(id);
		
		//send the email
		String recipientEmail=member.getEmail();
		String subject="Invitation to the senate Meeting";
		String message="Dear " + member.getName() + ",\n\nWe would like to invite you to join our team.\n\nBest regards,\nThe Team";
		emailService.sendEmail(recipientEmail, subject, message);
		
		/*
		 // update the status value in the invite table
		    Invite invite = inviteRepository.findByMemberId(id);
		    invite.setStatus(1);
		    inviteRepository.save(invite);
		
		
		// return the updated HTML code for the invite link
		return "<a th:text=\"" + (invite.getStatus() == 1 ? "Invite sent" : "Invite") + "\" th:href=\"@{/invitemember(id=${member.id})}\"></a>";
		*/
		
		//redirect to a success page
		return "adminpage";
	}	
}
