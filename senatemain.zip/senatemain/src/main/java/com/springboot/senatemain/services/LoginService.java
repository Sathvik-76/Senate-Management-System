package com.springboot.senatemain.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.senatemain.dao.AdminRepository;
import com.springboot.senatemain.dao.MemberRepository;
import com.springboot.senatemain.entities.Admin;
import com.springboot.senatemain.entities.Member;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
@Service
public class LoginService {
	
	@Autowired
	private MemberRepository memberRepository;
	
	@Autowired
	private AdminRepository adminRepository;
	
	public String login(String email,String password, HttpServletRequest request) {
		
		Member member=memberRepository.findByEmail(email);
		if(member!=null) {
			if(password.equals(member.getPassword())) {
				HttpSession session=request.getSession();
				session.setAttribute("privilege","member");
				session.setAttribute("id", member.getId());
				return "redirect:/memberpage";
			}
		}
		else {
			
			Admin admin=adminRepository.findByEmail(email);
			if(admin!=null) {
				if(password.equals(admin.getPassword())) {
					HttpSession session=request.getSession();
					session.setAttribute("privilege", "admin");
					return "redirect:/adminpage";
				}
				else {
	
					request.setAttribute("error","Invalid email or password");
					return "redirect:/";
				}
			}
		}
		request.setAttribute("error","Invalid email or password");
		return "redirect:/";
	}
}
