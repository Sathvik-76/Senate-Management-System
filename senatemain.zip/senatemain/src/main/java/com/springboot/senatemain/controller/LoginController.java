package com.springboot.senatemain.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.senatemain.services.LoginService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	@PostMapping("/login")
	public String login(@RequestParam("email") String email, @RequestParam("pass") String password, HttpServletRequest request) {
		return loginService.login(email, password, request);
	}
	
}
