package com.springboot.senatemain.entities;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="meeting")
public class Meeting {

	@Id
	@NotNull
	@Positive
	private int id;
	
	@NotNull
	@FutureOrPresent
	@Column(name = "date")
	private LocalDate date;
	
	@NotBlank
	@Size(min=2, max=100)
	@Column(name = "venue")
	private String venue;
	
	@NotNull
	@Column(name = "time")
	private LocalTime time;
	
	@Column(name = "flag")
	private int flag;
	
	@Column(name="agenda")
	private String agenda;
	
	@Column(name = "minutes")
	private String minutes;

	public Meeting() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Meeting(int id, LocalDate date, String venue, LocalTime time, int flag, String agenda, String minutes) {
		super();
		this.id = id;
		this.date = date;
		this.venue = venue;
		this.time = time;
		this.flag = flag;
		this.agenda = agenda;
		this.minutes = minutes;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public String getAgenda() {
		return agenda;
	}

	public void setAgenda(String agenda) {
		this.agenda = agenda;
	}

	public String getMinutes() {
		return minutes;
	}

	public void setMinutes(String minutes) {
		this.minutes = minutes;
	}

	@Override
	public String toString() {
		return "Meeting [id=" + id + ", date=" + date + ", venue=" + venue + ", time=" + time + ", flag=" + flag
				+ ", agenda=" + agenda + ", minutes=" + minutes + "]";
	}
	
	
}
