package com.springboot.senatemain.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.senatemain.dao.MemberRepository;
import com.springboot.senatemain.entities.Member;

@Service
public class MemberService {

	@Autowired
	private MemberRepository memberRepository;
	
	public Member getMemberById(int id) {
		return memberRepository.findById(id);
	}
}
