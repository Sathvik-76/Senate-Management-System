package com.springboot.senatemain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenatemainApplicationTests {

	@Test
	void contextLoads() {
	}

}
